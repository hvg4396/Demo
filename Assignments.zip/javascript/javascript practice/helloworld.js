function sayhello() {
	return "Hello World";
}
function sayboldhello() {
	return "<b style='font-family:consolas;'>Hello World<b>";
}