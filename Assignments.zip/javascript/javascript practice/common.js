var msg; msg='The actual script is in external script file called "common.js"';
function addNos(headVar,bodyVar)
	{
	document.write(msg+"<br>"};
	document.write("The sum of the variable and bodyVar is "+(headVar+bodyVar));
	}