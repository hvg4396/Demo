function valid(){
	var text="Hello World";
	document.write(text);
}