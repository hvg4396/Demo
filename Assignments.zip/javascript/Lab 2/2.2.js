<!DOCTYPE.html>
<html>
<head>
<script>
function test(){
var p=document.getElementById('p1').value;
var t=document.getElementById('t1').value;
var r=document.getElementById('r1').value;
var c=((p*(Math.pow((1+(r/100),t)))-p);
document.getElementById('p').innerHTML=p;
document.getElementById('t').innerHTML=t;
document.getElementById('r').innerHTML=r;
document.getElementById('c1').innerHTML=c;
return false;
}
</script>
</head>
<body>
<form onsubmit="return test()">
Principle:<input type="text" id="p1"><br>
Term:<input type="text" id="t1"><br>
Rate:<input type="text" id="r1"><br>
Compound_interest<span> <input type="button"id="c1" value="Compound_interest"></span>
</form>
</body>
</html>