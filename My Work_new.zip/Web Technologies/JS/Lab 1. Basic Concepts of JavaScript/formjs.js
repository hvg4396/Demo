	
function helloWorld()
{
	document.getElementById("here").innerHTML="Hello World";
	document.getElementById("here").style.fontFamily="monospace";
}

function addNumbers(headVar, bodyVar)
{
	return headVar+bodyVar;
}