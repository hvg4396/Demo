
	function isEverythingCorrect()
	{
		var gender = $("input.gender:checked").val();
		var moc = $("input.contact:checked").val();
		var state = document.getElementById("state").value;
		
		if(gender==undefined){
			alert("Please select a gender");
		return false;
		}
		
		if(moc==undefined){
			alert("Please select the preferred method of contact");
		return false;
		}
		
		if(state=="Select your state")
		{
			alert("Please select a state");
		return false;
		}
		
		return true;
	}