--LAB 5 QUESTIONS

--QUESTION 5.1
create table employee as select * from emp where 1=3;
desc employee;
select * from employee;

--QUESTION 5.2
insert into employee(empno,ename,sal,deptno)
select empno,ename,sal,deptno from emp;
select * from employee;

--QUESTION 5.3
UPDATE EMPLOYEE
SET JOB = replace(JOB, 'MANAGER', 'ANALYST'),
    DEPTNO = replace(DEPTNO, '30', '20');
SELECT * FROM EMPLOYEE;

--QUESTION 5.4
DELETE FROM EMP
WHERE JOB='SALESMAN';
SELECT * FROM EMP;
ROLLBACK
SELECT * FROM EMP;

--QUESTION 5.5
UPDATE EMP
SET DEPTNO = replace(DEPTNO, '20', '30');
SELECT * FROM EMP;

--QUESTION 5.6
insert into employee values(&empno,'&ename','&job','&mgr','&hiredate',&sal,&comm,&deptno);
SELECT * FROM EMPLOYEE;


