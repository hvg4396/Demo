select sm.staff_code "Staff#", sm.staff_name "Staff", dm.dept_name "Department", sm.mgr_code "Mgr#", 
sm.staff_name from 
department_master dm 
join staff_master sm
on dm.dept_code=sm.dept_code where staff_name like (select staff_name from staff_master where staff_code=mgr_code)



SELECT SM.STAFF_CODE, SM.STAFF_NAME, DM.DEPT_NAME, DSM.DESIGN_NAME, BM.BOOK_CODE, BM.BOOK_NAME, BT.BOOK_ISSUE_DATE FROM DEPARTMENT_MASTER DM JOIN STAFF_MASTER SM JOIN DESIGNATION_MASTER DSM JOIN BOOK_MASTER BM JOIN BOOK_TRANSACTIONS BT ON