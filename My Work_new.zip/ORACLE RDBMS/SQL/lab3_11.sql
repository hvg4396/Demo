select staff_name, count(staff_code) "Total Strength" from staff_master where mgr_code in (select mgr_code from staff_master group by mgr_code) group by staff_name, staff_code;
