--LAB 6 QUESTIONS

--QUESTION 6.1
insert into CUSTOMER values(&customerid,'&customername','&address1','&address2','&gender',&age,&phoneno,&salary);
select * from customer;

--QUESTION 6.2
SAVEPOINT SP1;

--QUESTION 6.3
insert into CUSTOMER values(&customerid,'&customername','&address1','&address2','&gender',&age,&phoneno,&salary);
select * from employee;

--QUESTION 6.4
ROLLBACK TO SP1;
SELECT * FROM CUSTOMER;
