create table mynewEmp
(
        id number(5) PRIMARY KEY,
        firstname varchar(15) NOT NULL,
        lastname varchar(15) NOT NULL,
        gender varchar(1) NOT NULL constraint ck_gen check(gender in ('M','F')),
        dob date NOT NULL,
        location varchar(15) NOT NULL,
        salary number(6) NOT NULL check(salary>10000)
);

Alter table mynewEmp
add constraint chck_gd CHECK(gender in('M','F')); 

alter TABLE mynewEmp
add constraint chck_dt check(dob < '04-Oct-2017');

create sequence seq_newEmp
start with 1
increment by 1
maxvalue 1000
nocycle;

create procedure pro_MnE
(
    fname in varchar2,
    lname in varchar2,
    gend in varchar2,
    dateob in date,
    loc in varchar2,
    sal in number,
    vid out number
)
as 
BEGIN
insert into mynewEmp values(seq_newEmp.nextval,fname,lname,gend,dateob,loc,sal);
select seq_newEmp.currval into vid from dual;
end;

variable empno number;
execute pro_MnE('&fname','&lname','&gend','&dateob','&loc',&sal,:empno);
print empno;





