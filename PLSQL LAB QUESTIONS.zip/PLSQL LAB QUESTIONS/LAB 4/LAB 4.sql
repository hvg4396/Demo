--LAB QUESTIONS 4

--LAB QUESTION 4.1
DECLARE
    
    m_sal STAFF_MASTERS.STAFF_SAL%TYPE;
    CURSOR mxSal_cuR(d_code NUMBER:=&EnterDeptCode)  IS
        select max(STAFF_SAL) from STAFF_MASTERS WHERE DEPT_CODE=d_code;
BEGIN
    IF NOT mxSal_cur%ISOPEN THEN
        OPEN mxSal_cur;
    END IF;
    LOOP
        FETCH mxSal_cur INTO m_sal;
        IF mxSal_cur%ROWCOUNT <1 THEN
            RAISE NO_DATA_FOUND;
        END IF;
        
        EXIT WHEN mxSal_cur%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(m_sal);
    END LOOP;
    CLOSE mxSal_cur;
    
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('NO SUCH DeptNo');
END;

--LAB QUESTION 4.2
    CREATE OR REPLACE FUNCTION AGE_dob(d_dob date) 
                    return number AS a number;
    BEGIN
       a:=round(MONTHS_BETWEEN(SYSDATE,D_DOB)/12);
       return a;
    END AGE_dob;
    
    DECLARE
        yrs NUMBER;
    BEGIN
        yrs:=AGE_dob('22-JUL-1996');
        DBMS_OUTPUT.PUT_LINE(yrs);
    END;
    
--LAB QUESTION 4.3
 create or replace procedure toUpperCase
(
SNo in staff_masters.staff_code%type,
SName out staff_masters.staff_name%type
)
as 
BEGIN
    select upper(STAFF_NAME) into SName from  staff_masters where staff_code=SNo;
    if(sql%notfound) then
        raise no_data_found;
    else 
     UPDATE staff_masters 
                SET staff_name=SName
                WHERE staff_code=SNo;
    end if;
exception
    when no_data_found then
        dbms_output.put_line('No data found');
    end;
    
    
variable name varchar2;
execute toUpperCase(&EnterStaffCode,:name);
print name;


--LAB QUESTION 4.4
create or replace procedure findMGR
(
SNo in staff_masters.staff_code%type,
SId out staff_masters.staff_code%type,
SName out staff_masters.staff_name%type,
DCode out staff_masters.dept_code%type,
MName out staff_masters.staff_name%type
)
as 
BEGIN
    select a.staff_code,a.staff_name,a.dept_code,b.staff_name as manager into SId,SName,DCode,MName 
    from  staff_masters a,staff_masters b 
    where a.mgr_code=b.staff_code and a.staff_code = SNo;
    if(sql%notfound) then
        raise no_data_found;
    end if;   
    exception
        when no_data_found then
            dbms_output.put_line('staff code not found');
end;

variable code number
variable name varchar2
variable dcode number
variable mname varchar2
execute findMGR(&id,:code,:name,:dcode,:mname);
print code;
print name;
print dcode;
print mname;



--LAB QUESTION 4.5
/*Write a function to compute the following. Function should take Staff_Code and return the cost to company.
DA = 15% Salary, HRA= 20% of Salary, TA= 8% of Salary.
Special Allowance will be decided based on the service in the company.
< 1 Year 				Nil
>=1 Year< 2 Year			10% of Salary
>=2 Year< 4 Year			20% of Salary
>4 Year				30% of Salary
*/
create or replace function CostToComp(code in number) return number
is
    sal staff_masters.staff_sal%type;
    exp number;
BEGIN
    select staff_sal,round(months_between(sysdate,hiredate)/12) as EXP into sal, exp from staff_masters where staff_code=code;
    if exp>4 then
    sal:=sal+ (0.3*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    elsif exp between 2 and 4 then
    sal:=sal+ (0.2*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    elsif exp between 1 and 2 then
    sal:=sal+ (0.1*sal)+(0.15*sal)+(0.2*sal)+(0.08*sal);
    else 
    sal:=sal+(0.15*sal)+(0.2*sal)+(0.08*sal);
    end if;
    return sal;
end;

DECLARE 
    CALC_SAL NUMBER;
BEGIN
    CALC_SAL:=CostToComp(&staff_code);
    dbms_output.put_line(CALC_SAL);
END;
        
    
--LAB QUESTION 4.6
/*
4.6. Write a procedure that displays the following information of all staff

Staff_Name    	  Department Name 	Designation 		Salary     	Status

Note: - Status will be (Greater, Lesser or Equal) respective to average salary of their own department. 
Display an error message Staff_Master table is empty if there is no matching record.
*/

create or replace procedure staff_info;

s_name staff_masters.staff_name%type;
d_name staff_masters.

