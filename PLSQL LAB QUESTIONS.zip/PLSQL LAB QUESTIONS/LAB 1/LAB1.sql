--LAB QUESTIONS 1

--LAB QUESTION 1.1
SELECT OBJECT_NAME, OBJECT_TYPE 
FROM USER_OBJECTS;

--LAB QUESTION 1.2
SELECT owner, table_name
FROM all_tables;
  
--LAB QUESTION 1.3  
SELECT TABLE_NAME,column_name
FROM user_tab_columns;
  
--LAB QUESTION 1.4
SELECT TABLE_NAME,CONSTRAINT_NAME FROM USER_CONSTRAINTS;

--LAB QUESTION 1.5
SELECT CONSTRAINT_NAME,TABLE_NAME FROM USER_CONSTRAINTS;

--LAB QUESTION 1.6
select view_name, text
from  user_views;

--LAB QUESTION 1.7
select sequence_name,last_number from user_sequences;

--LAB QUESTION 1.8
select synonym_name,table_name from user_synonyms;

--LAB QUESTION 1.9
select * from user_indexes;

