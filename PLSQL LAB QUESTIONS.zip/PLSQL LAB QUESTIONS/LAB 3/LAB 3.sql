--LAB QUESTIONS 3

--LAB QUESTION 3.1
--LAB QUESTION 2.1.3
DECLARE
    vid staff_masters.dept_code%TYPE:=&d_id;
    vcode staff_masters.staff_code%TYPE;
    vname staff_masters.staff_name%TYPE;
    vsal staff_masters.staff_sal%TYPE;
    CURSOR staff_Info IS
        SELECT staff_code, staff_name,staff_sal
        FROM staff_masters WHERE dept_code=vid;
BEGIN
    IF NOT staff_Info%ISOPEN THEN
          OPEN staff_Info;
    END IF;
    LOOP
        FETCH staff_Info INTO vcode,vname,vsal;
        if(staff_info%rowcount=0) then
            RAISE NO_DATA_FOUND;
        end if;
        EXIT WHEN staff_Info%NOTFOUND;
        dbms_output.put_line(vcode||' '||vname||' '||vsal);
    END LOOP;
    CLOSE staff_Info;
    EXCEPTION 
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('Wrong ID entered');  
        END; 

--LAB QUESTION 2.1.4
--2.1.4
DECLARE
      vd_code staff_masters.dept_code%TYPE:=&ID;
      v_sid staff_masters.staff_code%TYPE;
      v_sal staff_masters.staff_sal%TYPE;
      CURSOR sal_inc IS
          SELECT staff_code,staff_sal FROM staff_masters
          WHERE dept_code=vd_code;
BEGIN
      IF NOT sal_inc%ISOPEN THEN
            OPEN sal_inc;
      END IF;
      LOOP
          FETCH sal_inc INTO v_sid,v_sal;
          RAISE NO_DATA_FOUND;
          EXIT WHEN sal_inc%NOTFOUND;
          IF (v_sal*0.3)<5000 THEN
                UPDATE staff_masters 
                SET staff_sal=staff_sal+(v_sal*0.3)
                WHERE dept_code=vd_code AND staff_code=v_sid;
          ELSE
                UPDATE staff_masters
            
 SET staff_sal=v_sal+5000
                WHERE dept_code=vd_code AND staff_code=v_sid;
          END IF;
      END LOOP;
      CLOSE sal_inc;
      EXCEPTION 
            WHEN NO_DATA_FOUND THEN   
                  dbms_output.put_line('Invalid department code');
        END;
  
--lab question 2.1.5
--2.1.5 

DECLARE
      TYPE st_rec IS RECORD
      (
        v_scode student_masters.student_code%TYPE,
        v_sname student_masters.student_name %TYPE,
        v_sub1 student_marks.subject1%TYPE,
        v_sub2 student_marks.subject2%TYPE,
        v_sub3 student_marks.subject3%TYPE,
        total NUMBER(3),
        percentage NUMBER(5,2),
        grade VARCHAR2(2)
      );
      rec st_rec;
      v_dcode student_masters.dept_code%TYPE:=&deptcode;
      CURSOR st_report IS
          SELECT a.student_code,a.student_name,b.subject1,b.subject2,b.subject3,
          (b.subject1+b.subject2+b.subject3) AS TOTAL,((b.subject1+b.subject2+b.subject3)/3) AS PER, 
          CASE 
          WHEN ((b.subject1+b.subject2+b.subject3)/3) >=80 THEN 'A'
          WHEN ((b.subject1+b.subject2+b.subject3)/3) >=70 AND ((b.subject1+b.subject2+b.subject3)/3)<80 THEN 'B'
          WHEN ((b.subject1+b.subject2+b.subject3)/3) >=60 AND ((b.subject1+b.subject2+b.subject3)/3)<70 THEN 'C'
          ELSE 'D' 
          END AS GRADE
          FROM student_masters a JOIN student_marks b
          ON a.student_code=b.student_code
          WHERE a.dept_code=v_dcode;
BEGIN
      IF NOT st_report%ISOPEN THEN
            OPEN st_report;

     END IF;
      LOOP
            FETCH st_report INTO rec.v_scode,rec.v_sname,rec.v_sub1,rec.v_sub2,rec.v_sub3,rec.total,rec.percentage,rec.grade;
            RAISE NO_DATA_FOUND;
            EXIT WHEN st_report%NOTFOUND;
            dbms_output.put_line(rec.v_scode||' '||rec.v_sname||' '||rec.v_sub1||' '||rec.v_sub2||' '||rec.v_sub3||' '||rec.total||' '||rec.percentage||' '||rec.grade);
      END LOOP;
      CLOSE st_report;
      EXCEPTION
          WHEN NO_DATA_FOUND THEN 
                dbms_output.put_line('Data not found');
END;
/  

--LAB QUESTION 2.1.6

--2.1.6 
DECLARE
      st_row staff_masters%ROWTYPE;
      st_did staff_masters.dept_code%TYPE:=&id;
      CURSOR staff_info IS
              SELECT * FROM staff_masters
              WHERE dept_code=st_did;
BEGIN
      IF NOT staff_info%ISOPEN THEN
              OPEN staff_info;
      END IF;
      LOOP
              FETCH staff_info INTO st_row;
              RAISE NO_DATA_FOUND;
              EXIT WHEN staff_info%NOTFOUND;
              dbms_output.put_line(st_row.staff_code||' '||st_row.staff_name||' '||st_row.design_code||' '||st_row.dept_code||' '||st_row.staff_dob||' '||st_row.hiredate||' '||st_row.mgr_code||' '||st_row.staff_sal||' '||st_row.staff_address);
      END LOOP;
      CLOSE staff_info;
   EXCEPTION
          WHEN NO_DATA_FOUND THEN 
                dbms_output.put_line('Department code entered is Invalid');
END;
/  

--LAB QUESTION 3.2
DECLARE
    V_SAL STAFF_MASTERS.STAFF_SAL%TYPE;
    V_BONUS V_SAL%TYPE;
    CURSOR CAL_BONUS IS
        SELECT STAFF_SAL,(2*STAFF_SAL) AS BONUS
        FROM STAFF_MASTERS 
        WHERE MGR_CODE=100006;

BEGIN
      IF NOT CAL_BONUS%ISOPEN THEN
          OPEN CAL_BONUS;
      END IF;
      LOOP
          FETCH CAL_BONUS INTO V_SAL,V_BONUS;
          IF CAL_BONUS%ROWCOUNT<1 THEN
              RAISE NO_DATA_FOUND;
          END IF;
          DBMS_OUTPUT.PUT_LINE('STAFF SALARY IS ' || V_SAL);
          DBMS_OUTPUT.PUT_LINE('STAFF BONUS IS ' || V_BONUS);
      END LOOP;
      CLOSE CAL_BONUS;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('GIVEN CODE IS NOT VALID.ENTER VALID CODE');
END;
/ 

--LAB QUESTION 3.3

DECLARE
    V_SAL STAFF_MASTERS.STAFF_SAL%TYPE;
    V_BONUS STAFF_MASTERS.STAFF_SAL%TYPE;
    CURSOR CAL_BONUS IS
        SELECT STAFF_SAL, (STAFF_SAL)*2 AS BON
        FROM STAFF_MASTERS 
        WHERE MGR_CODE=100006;

BEGIN
      IF NOT CAL_BONUS%ISOPEN THEN
          OPEN CAL_BONUS;
      END IF;
      LOOP
          FETCH CAL_BONUS INTO V_SAL,V_BONUS;
            IF CAL_BONUS%ROWCOUNT<1 THEN
              RAISE NO_DATA_FOUND;
            END IF;
          DBMS_OUTPUT.PUT_LINE('STAFF SALARY IS ' || V_SAL);
          DBMS_OUTPUT.PUT_LINE('STAFF BONUS IS ' || V_BONUS);
      END LOOP;
      CLOSE CAL_BONUS;
EXCEPTION
      WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('GIVEN CODE IS NOT VALID,ENTER VALID CODE');
END;
/ 
--LAB QUESTION 3.4
BEGIN
      DECLARE
      fname emp.ename%TYPE;
      BEGIN
      SELECT ename INTO fname
      FROM emp
      WHERE 1=2;

      DBMS_OUTPUT.PUT_LINE('This statement will print');
      EXCEPTION
      WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Some inner block error');
      END;

 EXCEPTION
 WHEN NO_DATA_FOUND THEN
 DBMS_OUTPUT.PUT_LINE('No data found in fname');

 WHEN OTHERS THEN
 DBMS_OUTPUT.PUT_LINE('Some outer block error');
 END;
 
 --LAB QUESTION 3.6
 DECLARE
    null_value EXCEPTION;
    cmsn emp.comm%type;
    cursor comm_cur is
        select comm into cmsn from emp
        where empno=7369;
 BEGIN
    IF NOT comm_cur%ISOPEN then
        OPEN comm_cur;
    END IF;
    FETCH comm_cur into cmsn;
    if cmsn is null then
        RAISE null_value;
    ELSE
        DBMS_OUTPUT.PUT_LINE(cmsn);
    END IF;
    close comm_cur;
EXCEPTION 
    when null_value then
        DBMS_OUTPUT.PUT_LINE('ERROR! OOPS! COMMISSION IS A NULL VALUE');
END;

--lab question 3.7
CREATE PROCEDURE drop_table
(tname in varchar2) as 
BEGIN
    EXECUTE IMMEDIATE'drop table '||tname;
END;
/

EXECUTE drop_table('RAVI');




 
 
