
set SERVEROUTPUT ON;
--FINDING THE SUM OF THE TWO VALUES
declare
    num1 NUMBER:=0;
    num2 NUMBER:=0;
    num3 NUMBER:=0;    
begin
    num1:=&firstNumber;
    num2:=20;
    num3:=num1+num2;
    DBMS_OUTPUT.PUT_LINE(num3);
end;
/

--PRINTING THE SALARY OF THE EMPLOYEEE WITH ID=7876
DECLARE
    V_Salary EMP.SAL%TYPE;
BEGIN 
    SELECT SAL INTO V_Salary
    FROM emp WHERE EMPNO = 7876;
    DBMS_OUTPUT.put_line(V_Salary);
END;
/

--EXAMPLE FOR ROWTYPE

DECLARE 
    erow EMP%rowtype;
BEGIN
   select * into erow from EMP 
   where empno=7876;
   DBMS_OUTPUT.put_line(LOWER(erow.ename) || ' ' || erow.sal);
END;
/

--EXAMPLE FOR RECORD
DECLARE 
    type Dept_Rec IS record
    (
    did number(2,0),
    dname department_masters.dept_name%type
    );
    rec Dept_Rec;
begin
    select * into rec from department_masters
    where dept_code=30;
    DBMS_OUTPUT.PUT_LINE('ID:' || rec.did || '      Name:' || rec.dname);
end;
/

--EXAMPLE FOR TABLE DATA TYPE
DECLARE
    type Dept_Tab IS table of
    department_masters.dept_code%type 
    INDEX BY BINARY_INTEGER;
    department_masters.dept_name%type 
    );
    Dept Dept_Tab;
BEGIN
    select * into Dept from department_masters
    where dept_code=30;
    DBMS_OUTPUT.PUT_LINE('ID:' || Dept.did || '      Name:' || Dept.dname);
END;
/


--Example to meet the given requirements
DECLARE 
    salary number;
    empid number;
BEGIN
    empid:=&EnterEmployeeId;
    select sal into salary 
    from emp where empid=empno;
    
    if salary<1000 then
        DBMS_OUTPUT.PUT_LINE('OK' || ' ' || 'for' || ' ' || 'Salary:' || salary);
    ELSIF salary>1000 and salary<2500 then
        DBMS_OUTPUT.PUT_LINE('GOOD' || ' ' || 'for' || ' ' || 'Salary:' || salary);
    ELSIF salary>2500 and salary<4000 then
        DBMS_OUTPUT.PUT_LINE('GREAT' || ' ' || 'for' || ' ' || 'Salary:' || salary);
    ELSE
        DBMS_OUTPUT.PUT_LINE('EXCELLENT' || ' ' || 'for' || ' ' || 'Salary:' || salary);
    END IF;
END;
/


DECLARE
    n NUMBER;
    i NUMBER:=1;
BEGIN
    n:=&EnterLimitValue;
    loop
        DBMS_OUTPUT.PUT_LINE('2 *' || ' ' || i || ' ' || '=' || ' ' || (2*i) );
        i := i+1;
        exit when i > n;
    end loop;
end;
/

DECLARE
    n NUMBER;
    i NUMBER:=1;
BEGIN
    n:=&EnterLimitValue;
    loop
        if i<=n then
            DBMS_OUTPUT.PUT_LINE('2 *' || ' ' || i || ' ' || '=' || ' ' || (2*i) );
            i := i+1;
        else
            exit;
        end if;
    end loop;
end;
/


--DATE IS 04-10-2017

--CURSORS

BEGIN 
    update DEPARTMENT_MASTERS
    set DEPT_NAME='DUMMY'
    where DEPT_CODE=60;
    if sql%notfound then
        insert into DEPARTMENT_MASTERS
        VALUES(60,'DUMMY');
    end if;
end;
/

BEGIN 
    delete DEPARTMENT_MASTERS
    where DEPT_CODE=60;
    if sql%rowcount=1 then
        dbms_output.put_line('DOne.....');
    end if;
end;
/
select * from Department_masters;


set SERVEROUTPUT ON;

set serveroutput on;
--practice question for explicit cursor for dept_master

DECLARE
    c_deptid department_masters.dept_code%type;
    c_deptnm department_masters.dept_name%type;
    cursor c_deptMast IS select dept_code,dept_name from department_masters;
BEGIN
    if not c_deptMast%ISOPEN then
    open c_deptMast;
    end if;
    loop
        FETCH c_deptMast INTO
        c_deptid,c_deptnm;
        exit when c_deptMast%NOTFOUND;
        dbms_output.put_line(c_deptid || ' ' || upper(c_deptnm));
    END LOOP;
    CLOSE c_deptMast;
    
END;
/

--explicit cursors using record

DECLARE
    type Dept_Rec IS record
    (
     c_deptid department_masters.dept_code%type,
     c_deptnm department_masters.dept_name%type
    );
    rec Dept_Rec;
    cursor c_deptMast IS select dept_code,dept_name from department_masters;
BEGIN
    if not c_deptMast%ISOPEN then
    open c_deptMast;
    end if;
    loop
        FETCH c_deptMast INTO rec;
        exit when c_deptMast%NOTFOUND;
        dbms_output.put_line(rec.c_deptid || ' ' || upper(rec.c_deptnm));
    END LOOP;
    CLOSE c_deptMast;
    
END;
/

--question update salary of clerk by 10%
DECLARE
    TYPE MYREC IS RECORD
    (
        V_DCODE EMP.EMPNO% TYPE,
        V_SAL EMP.SAL% TYPE
    );
    RECC MYREC;
    CURSOR NEWC IS
    SELECT EMPNO,SAL FROM EMP WHERE job = 'CLERK';

BEGIN
     IF NOT NEWC %ISOPEN THEN
      OPEN NEWC;
     END IF;
     LOOP
        FETCH NEWC INTO RECC.V_DCODE,RECC.V_SAL;
        EXIT WHEN NEWC %NOTFOUND;
      UPDATE EMP SET SAL = 1.1* sal WHERE empno=RECC.V_DCODE;
    END LOOP;
    CLOSE NEWC;
END;
/ 
select * from emp;

set serveroutput on;
--EXCEPTION HANDLER EXAMPLE(IMPLICIT)

DECLARE
    did number(2,0):=&id;
    dname varchar2(50);
BEGIN
    select dept_name into dname from department_masters
    where dept_code = did;
   -- dbms_output.put_line(dname);
    Exception
        when no_data_found then
        dbms_output.put_line('Error');
end;
/



--PRACTICE QUESTION EXCEPTION HANDLING(EXPLICIT)

DECLARE
    eid number(4,0):=&id;
    esal number(7,2);
    HighSal Exception;
BEGIN
    select sal into esal from emp
    where empno=eid;
    if esal > 2500 then
        raise HighSal;
    else
        update emp 
        set sal = esal + 1
        where empno = eid;
    end if;
    Exception
        when HighSal then
            dbms_output.put_line('Cannot Update Salary for empno:' || ' ' || eid);
END;
/
SET SERVEROUTPUT ON;
--PRACTICE FOR PROCEDURE WITHOUT PARAMETER

create or replace procedure Proc1
as
BEGIN
    dbms_output.put_line('Hello from procedure');
END;
/

EXECUTE Proc1;

--PROCEDURE WITH PARAMETER
create or replace Procedure proc2
(
N1 in number,
N2 in number,
SUM out number
)
as 
BEGIN
SUM := N1 + N2;
end;
/

variable n number;
execute proc2(10,20,:n);
print n;
/

create or replace procedure MaxSal
(
MaxSalary out number
)
as
BEGIN
    select max(sal) into MaxSalary from emp;
END;

variable N;
EXECUTE MaxSal(:N);
print N;

--Procedure Example

create or replace procedure GetName
(
ENO in number,
Name out varchar2
)
as 
BEGIN
    select ename into Name from emp where empno=eno;
END;

variable nam varchar2;
execute GetName(&eno,:nam);
print nam;

SET SERVEROUTPUT ON;
--creation of a package 10/05/2017 11:19 am
--PACKAGE SPECIFICATION

create or replace package pack1 as
    procedure proc1;
    function fun1 return varchar2;
end pack1;

--CREATING PACKAGE BODY
CREATE OR REPLACE PACKAGE BODY pack1 as
    PROCEDURE proc1 is
    BEGIN
        dbms_output.put_line('hi a message from procedure');
    END proc1;
        function fun1 return varchar2 is
    BEGIN
        return ('hello from fun1');
    end fun1;
end pack1;

--EXECUTING PROCEDURE FROM PACKAGE

EXEC pack1.proc1;

--EXECUTING FUNCTION FROM A PACKAGE

select pack1.fun1 from dual;


--USING CURSOR VARIABLE IN A PACKAGE

CREATE OR REPLACE PACKAGE staff_data AS
    TYPE staffcurtyp IS REF CURSOR RETURN
        staff_masters%rowtype;
    PROCEDURE open_staff_cur(staff_cur IN OUT staffcurtyp);
    END staff_data; 


--implemented procedure

CREATE OR REPLACE PACKAGE BODY staff_data AS
PROCEDURE open_staff_cur(staff_cur IN OUT staffcurtyp) IS
BEGIN
   OPEN staff_cur FOR SELECT * FROM staff_masters;
   END open_staff_cur;
END staff_data; 

--TO RETRIEVE THE VALIUES FROM THE CURSOR
VARIABLE var_cur REFCURSOR
SET AUTOPRINT ON
EXECUTE staff_data.open_staff_cur(:var_cur)



--usage of triggers

CREATE OR REPLACE TRIGGER t
  BEFORE
    DELETE
  ON emp
BEGIN
  CASE
    WHEN DELETING THEN
      DBMS_OUTPUT.PUT_LINE('Deleting');
  END CASE;
END;




    
        