--LAB QUESTIONS 2

--LAB QUESTION 2.1
DECLARE
V_Sample1 NUMBER(2);
V_Sample2 CONSTANT NUMBER(2) ; --IF IT IS defined as constant then it needs to be initialised.
V_Sample3 NUMBER(2) NOT NULL ; --IF IT IS defined as NOT NULL then it needs to be initialised.
V_Sample4 NUMBER(2) := 50;
V_Sample5 NUMBER(2) DEFAULT 25;

--LAB QUESTION 2.2
/*
DECLARE --outer block
var_num1 NUMBER := 5;
BEGIN

DECLARE --inner block
var_num1 NUMBER := 10;
BEGIN
DBMS_OUTPUT.PUT_LINE('Value for var_num1:' ||var_num1);
--Can outer block variable (var_num1) be printed here.If Yes,Print the same.
END;
--Can inner block variable(var_num1)  be printed here.If Yes,Print the same.
END;

*/
<<BLOCK1>>
DECLARE
    var_num1 NUMBER := 5;
BEGIN
    <<BLOCK2>>
    DECLARE
        var_num1 NUMBER := 10;
    BEGIN
        DBMS_OUTPUT.PUT_LINE('Value for var_num1:' || BLOCK2.var_num1);
    END BLOCK2;
    
    DBMS_OUTPUT.PUT_LINE('Value for var_num1:' || BLOCK1.var_num1);
    
END BLOCK1;
/
SET SERVEROUTPUT ON;

--LAB QUESTION 2.3
/*Write a PL/SQL block to retrieve all staff (code, name, salary) under specific department number and display the result. 
(Note: The Department_Code will be accepted from user. Cursor to be used.)
*/
DECLARE 
    s_code STAFF_MASTERS.STAFF_CODE%TYPE;
    s_name STAFF_MASTERS.STAFF_NAME%TYPE;
    s_sal STAFF_MASTERS.STAFF_SAL%TYPE;
    d_code STAFF_MASTERS.DEPT_CODE%TYPE;
    CURSOR STAFF_CUR IS
        SELECT STAFF_CODE,STAFF_NAME,STAFF_SAL FROM STAFF_MASTERS where DEPT_CODE=d_code;
BEGIN
    d_code:=&EnterDeptCode;
    if not staff_cur%isopen then
    OPEN STAFF_CUR;
    end if;
    LOOP
        FETCH STAFF_CUR INTO s_code,s_name,s_sal;
        exit when STAFF_CUR%NOTFOUND;        
        DBMS_OUTPUT.PUT_LINE(s_code || ' ' || s_name || ' ' || ' ' || s_sal);        
    END LOOP;
    CLOSE STAFF_CUR;
END;
/
    
--LAB QUESTION 2.4
--Write a PL/SQL block to increase the salary by 30 % or 5000 whichever minimum for a given Department_Code
DECLARE
      vd_code staff_masters.dept_code%TYPE:=&ID;
      v_sid staff_masters.staff_code%TYPE;
      v_sal staff_masters.staff_sal%TYPE;
      CURSOR sal_inc IS
          SELECT staff_code,staff_sal FROM staff_masters
          WHERE dept_code=vd_code;
BEGIN
      IF NOT sal_inc%ISOPEN THEN
            OPEN sal_inc;
      END IF;
      LOOP
          FETCH sal_inc INTO v_sid,v_sal;
          EXIT WHEN sal_inc%NOTFOUND;    
    IF (v_sal*0.3)<5000 THEN
                UPDATE staff_masters 
                SET staff_sal=staff_sal+(v_sal*0.3)
                WHERE dept_code=vd_code AND staff_code=v_sid;
          ELSE
                UPDATE staff_masters 
                SET staff_sal=v_sal+5000
                WHERE dept_code=vd_code AND staff_code=v_sid;
          END IF;
      END LOOP;
      CLOSE sal_inc;
END;  
/
select staff_sal from staff_masters;

--LAB QUESTION 2.5
/*
Write a PL/SQL block to generate the following report for a given Department code

Student_Code  Sudent_Name   Subject1   Subject2   Subject3   Total  	Percentage   Grade

Note: Display suitable error massage if wrong department code has entered and if there is no student in the given department.

For Grade:
Student should pass in each subject individually (pass marks 60).
Percent >= 80 then grade= A
Percent >= 70 and < 80 then grade= B
Percent >= 60 and < 70 then grade= C
Else D
*/
DECLARE 
        s_deptno STUDENT_MASTERSS.DEPT_CODE%TYPE:=&EnterDeptCode;
        s_code STUDENT_MASTERSS.STUDENT_CODE%TYPE;
        s_name STUDENT_MASTERSS.STUDENT_NAME%TYPE;
        sub1 STUDENT_MARKSS.SUBJECT1%TYPE;
        sub2 STUDENT_MARKSS.SUBJECT2%TYPE;
        sub3 STUDENT_MARKSS.SUBJECT3%TYPE;
        percentage number(7,2);
        grade varchar2(4);
        CURSOR PerGra_cur IS
            select s.student_code,s.student_name,m.subject1,m.subject2,m.subject3,
            round((m.subject1+m.subject2+m.subject3)/3) as percentage,
            CASE 
                WHEN ((m.subject1+m.subject2+m.subject3)/3)>= 80 THEN 'A'
                WHEN ((m.subject1+m.subject2+m.subject3)/3) BETWEEN 70 AND 80 THEN 'B'
                WHEN ((m.subject1+m.subject2+m.subject3)/3) BETWEEN 60 AND 70 THEN 'C'
                ELSE 'D'
            END AS GRADE
            from student_masterss s, student_markss m
            where s.student_code=m.student_code and dept_code=s_deptno;
            
BEGIN
      IF NOT PerGra_cur%ISOPEN THEN
        OPEN PerGra_cur;
      END IF;
      LOOP
        FETCH PerGra_cur into s_code,s_name,sub1,sub2,sub3,percentage,grade;
        exit when PerGra_cur%NOTFOUND;
        DBMS_OUTPUT.PUT_LINE(s_code || ' ' || s_name || ' ' || sub1 || ' ' || sub2 || ' ' || sub3 || ' ' || (sub1+sub2+sub3) || ' ' || percentage || ' ' || grade);
      END LOOP;
        close PerGra_cur;
END;
/


--LAB 2.6 QUESTION
/*
Write a PL/SQL block to retrieve the details of the staff belonging to a particular department. 
Department code should be passed as a parameter to the cursor.
*/
DECLARE 
    inv_dept EXCEPTION;
    s_code STAFF_MASTERS.STAFF_CODE%TYPE;
    s_name STAFF_MASTERS.STAFF_NAME%TYPE;
    desg_code STAFF_MASTERS.design_code%TYPE;
    d_code STAFF_MASTERS.DEPT_CODE%TYPE:=&EnterDeptCode;
    stf_dob STAFF_MASTERS.staff_dob%TYPE;
    hired STAFF_MASTERS.hiredate%TYPE;
    mgr STAFF_MASTERS.mgr_code%TYPE;
    s_sal STAFF_MASTERS.STAFF_SAL%TYPE;
    stf_addr STAFF_MASTERS.staff_address%TYPE;
    CURSOR STFDET_CUR IS
        SELECT * FROM STAFF_MASTERS where DEPT_CODE=d_code;
BEGIN
    
    if not STFDET_CUR%isopen then
    OPEN STFDET_CUR;
    end if;
    LOOP
        FETCH STFDET_CUR INTO s_code,s_name,desg_code,d_code,stf_dob,hired,mgr,s_sal,stf_addr;
        IF STFDET_CUR%ROWCOUNT <1 THEN
            RAISE NO_DATA_FOUND;
        END IF;
        
        exit when STFDET_CUR%NOTFOUND;        
        DBMS_OUTPUT.PUT_LINE(s_code || ' ' || s_name || ' ' || ' ' || desg_code || ' ' || stf_dob || ' ' || hired || ' ' || mgr || ' ' || s_sal
        || ' ' || stf_addr);   
    END LOOP; 
    CLOSE STFDET_CUR;
    
    EXCEPTION
        WHEN inv_dept then
            dbms_output.put_line('Invalid Dept Number');
        WHEN NO_DATA_FOUND THEN
            dbms_output.put_line('NO SUCH DATA');   
END;
/


